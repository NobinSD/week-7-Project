import pandas as pd
import matplotlib.pyplot as plt

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


data = pd.read_csv("BreadBasket_DMS.csv")
data.dropna()
data = data[data["Item"] != "NONE"]
df = data.groupby(["Transaction", "Item"]).size().reset_index(name="Count")
basket = (
    df.groupby(["Transaction", "Item"])["Count"]
    .sum()
    .unstack()
    .reset_index()
    .fillna(0)
    .set_index("Transaction")
)


def encode_units(x):
    if x <= 0:
        return 0
    if x >= 1:
        return 1


basket_sets = basket.applymap(encode_units)
frequent_itemsets = apriori(basket_sets, min_support=0.01, use_colnames=True)

rules1 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.1)
rules1.sort_values("confidence", ascending=False, inplace=True)
rules2 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.2)
rules2.sort_values("confidence", ascending=False, inplace=True)
rules3 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.3)
rules3.sort_values("confidence", ascending=False, inplace=True)
rules4 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.4)
rules4.sort_values("confidence", ascending=False, inplace=True)
rules5 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.5)
rules5.sort_values("confidence", ascending=False, inplace=True)
rules6 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)
rules6.sort_values("confidence", ascending=False, inplace=True)
rules7 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.7)
rules7.sort_values("confidence", ascending=False, inplace=True)
rules8 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.8)
rules8.sort_values("confidence", ascending=False, inplace=True)
rules9 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.9)
rules9.sort_values("confidence", ascending=False, inplace=True)

pd.set_option("display.max_rows", 101, "display.max_columns", 101)


listofrules = []

# pd.set_option("display.max_rows", 101, "display.max_columns",101)
result1 = len(rules1)
result2 = len(rules2)
result3 = len(rules3)
result4 = len(rules4)
result5 = len(rules5)
result6 = len(rules6)
result7 = len(rules7)
result8 = len(rules8)
result9 = len(rules9)
listofrules.append(result1)
listofrules.append(result2)
listofrules.append(result3)
listofrules.append(result4)
listofrules.append(result5)
listofrules.append(result6)
listofrules.append(result7)
listofrules.append(result8)
listofrules.append(result9)
print("Number of Generated Rules: " + str(sum(listofrules)))
print("Rules for confidence 10%")
print(rules1)
print("Rules for confidence 20%")
print(rules2)
print("Rules for confidence 30%")
print(rules3)
print("Rules for confidence 40%")
print(rules4)
print("Rules for confidence 50%")
print(rules5)
print("Rules for confidence 60%")
print(rules6)
print("Rules for confidence 70%")
print(rules7)
print("Rules for confidence 80%")
print(rules8)
print("Rules for confidence 90%")
print(rules9)


class my_dictionary(dict):

    # __init__ function
    def __init__(self):
        self = dict()

    # Function to add key:value
    def add(self, key, value):
        self[key] = value


# Main Function
dict_obj = my_dictionary()
dict_obj.add("90%", result1)
dict_obj.add("80%", result2)
dict_obj.add("70%", result3)
dict_obj.add("60%", result4)
dict_obj.add("50%", result5)
dict_obj.add("40%", result6)
dict_obj.add("30%", result7)
dict_obj.add("20%", result8)
dict_obj.add("10%", result9)
names = list(dict_obj.keys())
values = list(dict_obj.values())
plt.bar(range(len(dict_obj)), values, tick_label=names)
plt.show()

print("Number of Rules generated for confidence 10%")
print(listofrules[0])
print("Number of Rules generated for confidence 20%")
print(listofrules[1])
print("Number of Rules generated for confidence 30%")
print(listofrules[2])
print("Number of Rules generated for confidencee 40%")
print(listofrules[3])
print("Number of Rules generated for confidence 50%")
print(listofrules[4])
print("Number of Rules generated for confidence 60%")
print(listofrules[5])
print("Number of Rules generated for confidencee 70%")
print(listofrules[6])
print("Number of Rules generated for confidence 80%")
print(listofrules[7])
print("Number of Rules generated for confidence 90%")
print(listofrules[8])
