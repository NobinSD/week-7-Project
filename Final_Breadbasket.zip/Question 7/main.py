import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("BreadBasket_DMS.csv")
df.drop(df[df['Item']=='NONE'].index,inplace=True)
df['Time'] = pd.to_datetime(df['Time'])


df['Hour'] = df['Time'].dt.hour


df=df["Hour"].value_counts().sort_values(ascending=False)

print("Hour"+" " +"Transaction")
print(df)
df.plot(kind="bar")

plt.show()