import pandas as pd
import matplotlib.pyplot as plt

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules


data = pd.read_csv("BreadBasket_DMS.csv")
data.dropna()
data = data[data["Item"] != "NONE"]
df = data.groupby(["Transaction", "Item"]).size().reset_index(name="Count")
basket = (
    df.groupby(["Transaction", "Item"])["Count"]
    .sum()
    .unstack()
    .reset_index()
    .fillna(0)
    .set_index("Transaction")
)


def encode_units(x):
    if x <= 0:
        return 0
    if x >= 1:
        return 1


basket_sets = basket.applymap(encode_units)
frequent_itemsets = apriori(basket_sets, min_support=0.005, use_colnames=True)

rules1 = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.1)
rules1.sort_values("confidence", ascending=False, inplace=True)


pd.set_option("display.max_rows", 101, "display.max_columns", 101)

listofrules = []
#
# pd.set_option("display.max_rows", 101, "display.max_columns",101)
result1 = len(rules1)


listofrules.append(result1)
print("Number of Generated Rules: " + str(sum(listofrules)))
print("Rules for confidence 10%")
print(rules1)


class my_dictionary(dict):

    # __init__ function
    def __init__(self):
        self = dict()

    # Function to add key:value
    def add(self, key, value):
        self[key] = value


# Main Function
dict_obj = my_dictionary()

dict_obj.add("10%", result1)
names = list(dict_obj.keys())
values = list(dict_obj.values())
plt.bar(range(len(dict_obj)), values, tick_label=names)
plt.show()
