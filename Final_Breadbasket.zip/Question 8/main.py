import pandas as pd
import matplotlib.pyplot as plt

# read the csv file as a dataframe
df = pd.read_csv("BreadBasket_DMS.csv")


def coffee_ext(group):
    match = group["Item"].str.contains("Coffee")
    return df.loc[match]


coffee = df[df["Item"].str.contains("Coffee")]["Transaction"].unique()
coffee = pd.DataFrame(coffee, columns=["Transaction"])
coffee_m = coffee.merge(df, left_on="Transaction", right_on="Transaction", how="right")
coffee_m = (
    coffee_m[~coffee_m.Item.str.contains("Coffee")]["Item"].value_counts().head(10)
)

print("The best item combinations with coffee")

print(coffee_m)
coffee_m.plot(kind="bar")

plt.show()
