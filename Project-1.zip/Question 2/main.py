# This is a sample Python script.

import pandas as pd
import calendar
import matplotlib.pyplot as plt
# read the csv file as a dataframe
bakery_dataset = pd.read_csv('BreadBasket_DMS.csv')
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']

bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])

bakery_dataset['Year'] = bakery_dataset['Date'].dt.year

first_year_data = bakery_dataset[bakery_dataset['Year'] == 2016]
topfive=first_year_data['Item'].value_counts().head(5)


print(topfive)
topfive.plot(kind="bar")

plt.show()









# df = pd.DataFrame({'Item': pd.date_range(start='30-10-2016', end='31-12-2016')})
# counted=df['Item'].value_counts()'
# df.resample('60min', base=30, label='right')['Item'].first()
# print(counted.to_numpy())
# pd.set_option("display.max_rows", 21293,"display.max_columns",101)
# print(counted.sort_values( ascending=False).head(10))
# print(counted)
