import pandas as pd
import matplotlib.pyplot as plt
# read the csv file as a dataframe
data = pd.read_csv('BreadBasket_DMS.csv')
coffee_transaction_list = data[data['Item'] == "Coffee"]["Transaction"].tolist()
data_copy = data.copy(deep=True)
data_copy = data_copy[data_copy['Transaction'].isin(coffee_transaction_list)]
data_copy.head(15)


hot_items_coffe_combine = data_copy.Item.value_counts()[:10]

hot_items = data.Item.value_counts()[:10]

# We need to drop coffee values beacuse we don't need it when we compare items with coffee or without coffee
hot_items_coffe_combine = hot_items_coffe_combine.drop(labels=["Coffee"])
hot_items = hot_items.drop(labels=["Coffee"])

# Labels are Item names
labels = hot_items_coffe_combine.index.values.tolist()

# And values are just values :/
values_coffe_combine = hot_items_coffe_combine.tolist()
values = hot_items.tolist()

# First time when I wrote this kernel I made a critical mistake.
# We need to subtract values_coffe_combine from values to get values_without_coffee.
# I forgot to do this step.
values_without_coffee = [values[i]-v for i,v in enumerate(values_coffe_combine)]

df = pd.DataFrame({'with_coffee':values_coffe_combine, 'without_coffee':values_without_coffee})
print(df)