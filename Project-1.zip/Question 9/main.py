import pandas as pd
import matplotlib.pyplot as plt


bakery_dataset = pd.read_csv("BreadBasket_DMS.csv")
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']


def map_indexes_and_values(df, col):
    df_col = df[col].value_counts()
    x = df_col.index.tolist()
    y = df_col.values.tolist()
    return x, y


weekmap = {0: 'Mon', 1: 'Tue', 2: 'Wed', 3: 'Thu', 4: 'Fri', 5: 'Sat', 6: 'Sun'}
popular_items, popular_items_count = map_indexes_and_values(bakery_dataset, 'Item')

bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])

bakery_dataset['Year'] = bakery_dataset['Date'].dt.year

bakery_dataset['Weekday'] = bakery_dataset['Date'].dt.weekday

sevenitem = bakery_dataset[bakery_dataset['Year'] == 2017]
first_item = sevenitem[sevenitem['Item'] == popular_items[0]]
weekday, weekday_count = map_indexes_and_values(first_item, 'Weekday')

orderday = weekmap.values()
new = pd.DataFrame.from_dict(orderday)
ordervalues = weekday_count
new1 = pd.DataFrame(ordervalues)
new2 = pd.concat([new, new1], axis=1)
new3 = new2.head(5)
print(new2.head(5))
new3.plot(kind="bar")
plt.xlabel('Weekday')
plt.ylabel('Number of Transactions')

plt.show()


