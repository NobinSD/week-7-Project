import pandas as pd
import matplotlib.pyplot as plt

bakery_dataset = pd.read_csv("BreadBasket_DMS.csv")
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']
def map_indexes_and_values(df, col):
    df_col = df[col].value_counts()
    x = df_col.index.tolist()
    y = df_col.values.tolist()
    return x, y


bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])
bakery_dataset['Time'] = pd.to_datetime(bakery_dataset['Time'])
bakery_dataset['Year'] = bakery_dataset['Date'].dt.year
bakery_dataset['Month'] = bakery_dataset['Date'].dt.month
bakery_dataset['Day'] = bakery_dataset['Date'].dt.day
bakery_dataset['Weekday'] = bakery_dataset['Date'].dt.weekday
bakery_dataset['Hour'] = bakery_dataset['Time'].dt.hour
weekmap = {0:'Mon', 1:'Tue', 2:'Wed', 3:'Thu', 4:'Fri', 5:'Sat', 6:'Sun'}

# count of the five most popular items
popular_items, popular_items_count = map_indexes_and_values(bakery_dataset, 'Item')

second_item = bakery_dataset[bakery_dataset['Item'] == popular_items[1]]
print(popular_items[1])
weekday, weekday_count = map_indexes_and_values(second_item, 'Weekday')
x2 = [weekmap[x] for x in weekday]
wkmp = {}
for j,x in enumerate(x2):
    wkmp[x] = weekday_count[j]
order = list(weekmap.values())
ordervals = [wkmp[val] for val in order]
plt.bar(order, ordervals, color='magenta')
plt.xlabel('Weekday')
plt.ylabel('Number of Transactions')
plt.title('Popularity of '+popular_items[1]+' by weekday')
plt.show()
