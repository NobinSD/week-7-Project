import pandas as pd
import calendar
import matplotlib.pyplot as plt
# read the csv file as a dataframe
bakery_dataset = pd.read_csv('BreadBasket_DMS.csv')
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']

bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])

bakery_dataset['Year'] = bakery_dataset['Date'].dt.year

first_year_data = bakery_dataset[bakery_dataset['Year'] == 2017]
topfive=first_year_data['Item'].value_counts().head(5)


print(topfive)
topfive.plot(kind="bar")

plt.show()