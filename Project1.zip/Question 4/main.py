import pandas as pd
import matplotlib.pyplot as plt
# read the csv file as a dataframe
bakery_dataset = pd.read_csv('BreadBasket_DMS.csv')
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']

bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])

bakery_dataset['Weekday'] = bakery_dataset['Date'].dt.weekday

weekmap = {0:'Mon', 1:'Tue', 2:'Wed', 3:'Thu', 4:'Fri', 5:'Sat', 6:'Sun'}

monday_info = bakery_dataset[bakery_dataset['Weekday'] == 0]
print(monday_info['Item'].value_counts().head(5))
