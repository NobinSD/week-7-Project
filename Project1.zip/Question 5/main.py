import pandas as pd
import matplotlib.pyplot as plt
# read the csv file as a dataframe
data = pd.read_csv('BreadBasket_DMS.csv')
data['Date_Time']=pd.to_datetime(data['Date']+' '+data['Time'])
data['Day']=data['Date_Time'].dt.day_name()
data['Month']=data['Date_Time'].dt.month
data['Month_name']=data['Date_Time'].dt.month_name()
data['Year']=data['Date_Time'].dt.year
data['Year_Month']=data['Year'].apply(str)+' '+data['Month_name'].apply(str)
data.drop(['Date','Time'], axis=1, inplace=True)
result=data.groupby('Year_Month')['Item'].count()
print(result)

result.plot(kind='bar')
plt.show()