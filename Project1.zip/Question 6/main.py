import pandas as pd
import matplotlib.pyplot as plt
# read the csv file as a dataframe
bakery_dataset = pd.read_csv('BreadBasket_DMS.csv')
bakery_dataset.dropna()
bakery_dataset = bakery_dataset[bakery_dataset['Item'] != 'NONE']

bakery_dataset['Date'] = pd.to_datetime(bakery_dataset['Date'])
bakery_dataset['Time'] = pd.to_datetime(bakery_dataset['Time'])
bakery_dataset['Year'] = bakery_dataset['Date'].dt.year
bakery_dataset['Month'] = bakery_dataset['Date'].dt.month
bakery_dataset['Day'] = bakery_dataset['Date'].dt.day
bakery_dataset['Weekday'] = bakery_dataset['Date'].dt.weekday
bakery_dataset['Hour'] = bakery_dataset['Time'].dt.hour
weekmap = {0:'Mon', 1:'Tue', 2:'Wed', 3:'Thu', 4:'Fri', 5:'Sat', 6:'Sun'}

monday = bakery_dataset[bakery_dataset['Weekday'] == 0]
tuesday = bakery_dataset[bakery_dataset['Weekday'] == 1]
wednesday = bakery_dataset[bakery_dataset['Weekday'] == 2]
thursday = bakery_dataset[bakery_dataset['Weekday'] == 3]
friday = bakery_dataset[bakery_dataset['Weekday'] == 4]
saturday = bakery_dataset[bakery_dataset['Weekday'] == 5]
sunday = bakery_dataset[bakery_dataset['Weekday'] == 6]

print ('Item sold on Monday')
monday=monday['Item'].count()
print(monday)
print ('Item sold on Tuesday')
tuesday=tuesday['Item'].count()
print(tuesday)
print ('Item sold on Wednesday')
wednesday=wednesday['Item'].count()
print(wednesday)
print ('Item sold on Thursday')
thursday=thursday['Item'].count()
print(thursday)
print ('Item sold on Friday')
friday=friday['Item'].count()
print(friday)


class my_dictionary(dict):

    # __init__ function
    def __init__(self):
        self = dict()

    # Function to add key:value
    def add(self, key, value):
        self[key] = value


# Main Function
dict_obj = my_dictionary()
dict_obj.add(monday,weekmap[0])
dict_obj.add(tuesday,weekmap[1])
dict_obj.add(wednesday,weekmap[2])
dict_obj.add(thursday,weekmap[3])
dict_obj.add(friday,weekmap[4])

names = list(dict_obj.keys())
values = list(dict_obj.values())

plt.bar( values,names)
plt.show()
# print(weekmap[1])
# print ('Item sold on Saturday')
# print(saturday['Item'].count())
# print ('Item sold on Sunday')
# print(saturday['Item'].count())
