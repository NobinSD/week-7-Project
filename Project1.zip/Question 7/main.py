import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("BreadBasket_DMS.csv")
# df.drop(df[df['Item']=='NONE'].index,inplace=True)

# Create month and hour columns
# df['Month'] = df['Date'].apply(lambda x:x.split("-")[1])
df['Hour'] = df['Time'].apply(lambda x:int(str(pd.to_datetime(x).round('H')).split(" ")[1].split(":")[0]))


df=df["Hour"].value_counts().sort_values(ascending=False)
print("Hour"+" " +"Transaction")
print(df)
df.plot(kind="bar")

plt.show()